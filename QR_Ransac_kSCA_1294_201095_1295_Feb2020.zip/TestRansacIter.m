l=1:15;
w=0.1;
Out=abs(1./log10(1-w.^l));
plot(l,Out)