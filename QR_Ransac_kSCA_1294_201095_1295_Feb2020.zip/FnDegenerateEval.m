function r=FnDegenerateEval(x,d)
r=rank(x)<d;