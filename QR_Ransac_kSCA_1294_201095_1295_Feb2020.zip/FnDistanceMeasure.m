function d=FnDistanceMeasure(v,B)
%Equation 11
d=sqrt(1-sum((v*B).^2));


